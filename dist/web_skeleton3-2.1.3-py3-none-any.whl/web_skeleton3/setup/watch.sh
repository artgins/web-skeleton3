#!/bin/sh
make
watchfs -f watch.json

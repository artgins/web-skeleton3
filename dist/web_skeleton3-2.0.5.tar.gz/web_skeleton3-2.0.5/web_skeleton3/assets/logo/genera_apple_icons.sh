inkscape sample.svg --export-png=icon.png -w192 -h192
inkscape sample.svg --export-png=favicon.ico -w32 -h32
inkscape sample.svg --export-png=tile-wide.png -w558 -h270
inkscape sample.svg --export-png=tile.png -w558 -h558

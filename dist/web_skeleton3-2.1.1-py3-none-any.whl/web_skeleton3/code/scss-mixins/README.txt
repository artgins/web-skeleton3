Create here your @mixin of scss
